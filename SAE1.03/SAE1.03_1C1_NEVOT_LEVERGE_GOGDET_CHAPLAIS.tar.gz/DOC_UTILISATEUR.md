# Titre du projet
Description du projet

Version du de la doc

Date d'itération

Exemple :
Ce projet est un projet de test pour apprendre à utiliser git et github

## Prérequis
Liste des prérequis

Exemple :

- Distribution Linux | Debian, Ubuntu
- Distribution Windows | Windows 10|11
- git
- un compte github

## Installation
Guide d'intallation

Exemple :
Pour installer ce projet, il suffit de le cloner sur votre machine avec la commande suivante :

```bash
git clone {url du projet}
```

## Utilisation
Guide d'utilisation
Avec les commandes à utiliser et exemple de fonctionnement

Exemple :
git add : permet d'ajouter un fichier à l'index

```bash
git add {nom du fichier}
```

git commit : permet de créer un commit avec les fichiers de l'index

```bash
git commit -m "Message du commit"
```
