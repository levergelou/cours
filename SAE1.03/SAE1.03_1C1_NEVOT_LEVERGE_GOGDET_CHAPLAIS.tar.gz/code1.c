/**
 * Ce programme permet de gérer une élection et une bibliothèque.
 * Il est composé de deux parties :
 * - la première permet de gérer une élection entre deux candidats
 * - la seconde permet de gérer une bibliothèque
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAXC 2  /** Maximum de candidats pour l'élection */
#define MAXL 50000  /** Maximum de livres dans la bibliothèque */

/**
 * \struct t_Candidat
 * \brief Structure représentant un candidat avec son nom, son âge et le nombre de voix.
 */
typedef struct {
    char nom[30];  /**< Nom du candidat */
    int age;       /**< Âge du candidat */
    int nbVoix;    /**< Nombre de voix du candidat */
} t_Candidat;

/**
 * \struct t_lecteur
 * \brief Structure représentant un lecteur avec son numéro, son nom, son prénom, les livres empruntés et le nombre d'emprunts.
 */
typedef struct {
    int numero;               /**Numéro du lecteur */
    char nom[30];             /**Nom du lecteur */
    char prenom[30];          /**Prénom du lecteur */
    t_livre livres[MAXL];     /**Livres empruntés par le lecteur */
    int nbEmprunts;           /**Nombre d'emprunts du lecteur */
} t_lecteur;

/**
 * \brief Fonction de saisie d'un candidat.
 * \return Le candidat saisi.
 */
t_Candidat saisie();

/**
 * \brief Fonction de comparaison de deux candidats.
 * \param c1 Premier candidat.
 * \param c2 Deuxième candidat.
 * \return 1 si c1 a plus de voix ou est plus jeune, -1 si c2 a plus de voix ou est plus jeune, 0 en cas d'égalité.
 */
int compare(t_Candidat c1, t_Candidat c2);

// Exercice 2
#define MAXL 50000  /**< Maximum de livres dans la bibliothèque */

/**
 * \struct t_livre
 * \brief Structure représentant un livre avec sa référence, son titre, son auteur et sa disponibilité.
 */
typedef struct {
    int c_ref;                /**< Référence du livre */
    char c_titre[30];         /**< Titre du livre */
    char c_auteur[30];        /**< Auteur du livre */
    bool c_present;           /**< Disponibilité du livre */
} t_livre;

/**
 * \struct t_lecteur
 * \brief Structure représentant un lecteur avec son numéro, son nom, son prénom, les livres empruntés et le nombre d'emprunts.
 */
typedef struct {
    int numero;               /**< Numéro du lecteur */
    char nom[30];             /**< Nom du lecteur */
    char prenom[30];          /**< Prénom du lecteur */
    t_livre livres[MAXL];     /**< Livres empruntés par le lecteur */
    int nbEmprunts;           /**< Nombre d'emprunts du lecteur */
} t_lecteur;

/**
 * \struct t_bib
 * \brief Structure représentant une bibliothèque avec son contenu, le nombre de livres et les lecteurs.
 */
typedef struct {
    t_livre c_contenu[MAXL];  /**< Contenu de la bibliothèque */
    int c_nbre;               /**< Nombre de livres dans la bibliothèque */
    t_lecteur lecteurs;       /**< Les lecteurs de la bibliothèque */
} t_bib;

/**
 * \brief Fonction d'affichage d'un livre.
 * \param livre Le livre à afficher.
 */
void afficheLivre(t_livre livre);

/**
 * \brief Fonction de saisie d'un livre.
 * \return Le livre saisi.
 */
t_livre saisieLivre();

/**
 * \brief Fonction d'insertion d'un livre dans une bibliothèque.
 * \param livre Le livre à insérer.
 * \param bib La bibliothèque où insérer le livre.
 */
void insertion(t_livre livre, t_bib bib);

/**
 * \brief Fonction d'affichage de la liste des livres d'une bibliothèque.
 * \param bib La bibliothèque à afficher.
 */
void afficheBib(t_bib bib);

/**
 * \brief Fonction d'enregistrement de l'emprunt d'un livre de la bibliothèque.
 * \param bib La bibliothèque où enregistrer l'emprunt.
 */
void emprunt(t_bib bib);

/**
 * \brief Fonction d'ajout d'un lecteur dans une bibliothèque.
 * \param bib La bibliothèque où ajouter le lecteur.
 */
void ajoutLecteur(t_bib bib);

/**
 * \brief Fonction principale pour les deux exercices.
 * \return 0 si tout s'est bien déroulé.
 */
int main();

/**
 * \brief Fonction pour l'exercice 1.
 */
void ex1();

/**
 * \brief Fonction pour l'exercice 2.
 */
void ex2();

/**
 * \brief Fonction principale pour l'exercice 1.
 * Demande la saisie de deux candidats, les compare et affiche le résultat.
 */
void ex1() {
    t_Candidat candidat1;
    t_Candidat candidat2;
    int resultat;

    candidat1 = saisie();
    candidat2 = saisie();
    resultat = compare(candidat1, candidat2);
    if (resultat == 1) {
        printf("Le candidat %s est le gagnant\n", candidat1.nom);
    } else {
        if (resultat == -1) {
            printf("Le candidat %s est le gagnant\n", candidat2.nom);
        } else {
            printf("Egalité\n");
        }
    }
}

/**
 * \brief Fonction de saisie d'un candidat.
 * \return Le candidat saisi.
 */
t_Candidat saisie() {
    t_Candidat candidat;
    printf("Nom du candidat : ");
    scanf("%s", candidat.nom);
    printf("Age du candidat : ");
    scanf("%d", &candidat.age);
    printf("Nombre de voix du candidat : ");
    scanf("%d", &candidat.nbVoix);
    return candidat;
}

/**
 * \brief Fonction de comparaison de deux candidats.
 * \param c1 Premier candidat.
 * \param c2 Deuxième candidat.
 * \return 1 si c1 a plus de voix ou est plus jeune, -1 si c2 a plus de voix ou est plus jeune, 0 en cas d'égalité.
 */
int compare(t_Candidat c1, t_Candidat c2) {
    if (c1.nbVoix > c2.nbVoix) {
        return 1;
    } else {
        if (c1.nbVoix < c2.nbVoix) {
            return -1;
        } else {
            if (c1.age > c2.age) {
                return 1;
            } else {
                if (c1.age < c2.age) {
                    return -1;
                } else {
                    return 0;
                }
            }
        }
    }
}

/**
 * \brief Fonction principale pour l'exercice 2.
 * Permet de gérer les actions possibles dans une bibliothèque.
 */
void ex2() {
    t_bib bib;
    t_livre livre;
    int choix;
    bib.c_nbre = 0;
    bib.lecteurs.nbLecteurs = 0;

    do {
        printf("Choix de l\'action à effectuer : \n");
        printf("1. Afficher un livre\n");
        printf("2. Saisir un livre\n");
        printf("3. Insérer un livre dans une bibliothèque\n");
        printf("4. Afficher la liste des livres d’une bibliothèque\n");
        printf("5. Enregistrer l’emprunt d’un livre de la bibliothèque\n");
        printf("6. Ajouter un lecteur dans une bibliothèque\n");
        printf("7. Quitter\n");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                livre = saisieLivre();
                afficheLivre(livre);
                break;
            case 2:
                livre = saisieLivre();
                break;
            case 3:
                insertion(livre, bib);
                break;
            case 4:
                afficheBib(bib);
                break;
            case 5:
                emprunt(bib);
                break;
            case 6:
                ajoutLecteur(bib);
                break;
            case 7:
                printf("Au revoir\n");
                break;
            default:
                printf("Choix invalide\n");
                break;
        }
    } while (choix != 7);
}

/**
 * \brief Fonction d'affichage d'un livre.
 * \param livre Le livre à afficher.
 */
void afficheLivre(t_livre livre) {
    printf("Référence : %d\n", livre.c_ref);
    printf("Titre : %s\n", livre.c_titre);
    printf("Auteur : %s\n", livre.c_auteur);
    printf("Présent : %d\n", livre.c_present);
}

/**
 * \brief Fonction de saisie d'un livre.
 * \return Le livre saisi.
 */
t_livre saisieLivre() {
    t_livre livre;
    printf("Référence : ");
    scanf("%d", &livre.c_ref);
    printf("Titre : ");
    scanf("%s", livre.c_titre);
    printf("Auteur : ");
    scanf("%s", livre.c_auteur);
    printf("Présent : ");
    scanf("%d", &livre.c_present);
    return livre;
}

/**
 * \brief Fonction d'insertion d'un livre dans une bibliothèque.
 * \param livre Le livre à insérer.
 * \param bib La bibliothèque où insérer le livre.
 */
void insertion(t_livre livre, t_bib bib) {
    bib.c_contenu[bib.c_nbre] = livre;
    bib.c_nbre = bib.c_nbre + 1;
}

/**
 * \brief Fonction d'affichage de la liste des livres d'une bibliothèque.
 * \param bib La bibliothèque à afficher.
 */
void afficheBib(t_bib bib) {
    int i;
    for (i = 0; i < bib.c_nbre; i++) {
        afficheLivre(bib.c_contenu[i]);
    }
}

/**
 * \brief Fonction d'enregistrement de l'emprunt d'un livre de la bibliothèque.
 * \param bib La bibliothèque où enregistrer l'emprunt.
 */
void emprunt(t_bib bib) {
    int ref;
    printf("Référence du livre à emprunter : ");
    scanf("%d", &ref);
    bib.c_contenu[ref].c_present = 0;
}

/**
 * \brief Fonction d'ajout d'un lecteur dans une bibliothèque.
 * \param bib La bibliothèque où ajouter le lecteur.
 */
void ajoutLecteur(t_bib bib) {
    bib.lecteurs.nbLecteurs = bib.lecteurs.nbLecteurs + 1;
    bib.lecteurs.lecteurs[bib.lecteurs.nbLecteurs].numero = bib.lecteurs.nbLecteurs;
    printf("Nom du lecteur : ");
    scanf("%s", bib.lecteurs.lecteurs[bib.lecteurs.nbLecteurs].nom);
    printf("Prénom du lecteur : ");
    scanf("%s", bib.lecteurs.lecteurs[bib.lecteurs.nbLecteurs].prenom);
}

/**
 * \brief Fonction principale pour les deux exercices.
 * \return 0 si tout s'est bien déroulé.
 */
int main() {
    int choix;
    printf("Choix de l\'exercice à lancer : \n");
    printf("1. Exercice 1\n");
    printf("2. Exercice 2\n");
    scanf("%d", &choix);

    switch (choix) {
        case 1:
            ex1();
            break;
        case 2:
            ex2();
            break;
        default:
            printf("Choix invalide\n");
            break;
    }

    return 0;
}