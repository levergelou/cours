/**
 * \brief Tris
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define N 10 /** Taille du tableau */
typedef int tablo[N]; /** Définition d'un tableau d'entiers */
#define MAX 100 /** Valeur maximale des éléments du tableau */

/**
 * Affiche les éléments d'un tableau.
 * 
 * \param t Tableau à afficher
 * \param n Taille du tableau
 */
void affiche(tablo t, int n){
    int i;
    for (i = 0; i < n; i++)
    {
        printf("%d ", t[i]);
    }   
}

/**
 * Trie le tableau T par sélection (ordre croissant).
 * 
 * \param T Tableau à trier
 */
void tri_selection(tablo T){
    int i, j, tmp, min;
    for (i = 0; i < N; i++)
    {
        min = i;
        for (j = i+1; j < N; j++)
        {
            if (T[j] < T[min])
            {
                min = j;
            }
        }
        tmp = T[i];
        T[i] = T[min];
        T[min] = tmp;
    }
}

/**
 * Trie le tableau T par sélection (ordre décroissant).
 * 
 * \param T Tableau à trier
 */
void tri_selection_decroissant(tablo T){
    int i, j, tmp, min;
    for (i = 0; i < N; i++)
    {
        min = i;
        for (j = i+1; j < N; j++)
        {
            if (T[j] > T[min])
            {
                min = j;
            }
        }
        tmp = T[i];
        T[i] = T[min];
        T[min] = tmp;
    }
}

/**
 * Fonction principale
 */
int main(){
    tablo t = {4, 1, 5, 9, 10, 11, 3, 8, 6, 7};
    
    // Affiche le tableau initial
    printf("Tableau initial: ");
    affiche(t, N);
    printf("\n");
    
    // Trie le tableau par sélection (ordre croissant)
    tri_selection(t);
    
    // Affiche le tableau trié
    printf("Tableau trié (croissant): ");
    affiche(t, N); 
    
    return 0;
}