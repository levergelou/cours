/**
 * \brief Programme principal du jeu Sudoku
 * 
 * Ce programme permet de jouer au Sudoku. Il permet de charger une grille depuis un fichier, de l'afficher, de la compléter et de vérifier si elle est valide.
 */

/**
 * Définir un drapeau de mode debug
 * 
 * Définir ce drapeau à 1 pour activer le mode debug, qui affichera des informations supplémentaires sur la console.
 */
#define DEBUG 0 // >:( 

/**
 * Macro préprocesseur pour définir la taille en n*n de la grille.
 */
#define SIZE 9

/**
 * \typedef typedef int tGrille[SIZE][SIZE];
 * 
 * Définir un type pour une grille Sudoku
 *
 * Une grille Sudoku est un tableau n*n d'entiers, où chaque entier peut avoir une valeur comprise entre 1 et n**2 ou 0 si la case est vide.
 */
typedef int tGrille[SIZE][SIZE];

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <locale.h> // utf8

// PROCEDURES

/**
 * Charger la grille depuis un fichier.
 * 
 * Cette fonction permet de charger une grille depuis un fichier. Le fichier doit être au format ".sud". Il vérifie aussi que le fichier existe et sa validité.
 * 
 * \param g Grille à charger
 */
void chargerGrille(tGrille g);

/**
 * Afficher la grille.
 * 
 * Cette fonction permet d'afficher une grille.
 * 
 * \param g Grille à afficher
 */
void afficheGrille(tGrille g);

/**
 * Saisir une valeur.
 * 
 * Cette fonction permet de saisir une valeur entre 1 et n².
 * 
 * \param pos Pointeur sur la variable qui contiendra la valeur saisie.
 */
void saisir(int *x);

// FONCTIONS

/**
 * Vérifier la validité d'une valeur.
 * 
 * Cette fonction permet de vérifier si une valeur n est placable sur les coordonnées (x,y) passées en paramètres dans la grille g.
 * 
 * \param x Position x de la valeur
 * \param y Position y de la valeur
 * \param n Valeur à vérifier
 * \param g Grille dans laquelle la valeur doit être vérifiée
 * 
 * \return Vrai si la peut être mise à l'endroit désiré ou non.
 */
bool possible(int x, int y, int n, tGrille g);

/**
 * Vérifier la complétude de la grille.
 * 
 * Cette fonction permet de vérifier si une grille est complète.
 * 
 * \param g Grille à vérifier
 * 
 * \return Vrai si la grille est complète, faux sinon
 */
bool grillePleine(tGrille g);

/**
 * Programme principal.
 * 
 * Cette fonction est le programme principal du sudoku et à pour seule utilité d'appeler les fonctions principales et de tourner tant que l'utilisateur veut rejouer et que la grille n'est pas pleine.
 * 
 * \return 0 -> programme quitte sans erreur, autre -> une erreur est survenue.
 */
int main(int argc, char *argv[]) {
    setlocale(LC_CTYPE, "fr_FR.UTF8");
    int posx, posy, val;
    char resp[50];
    bool restart = true;
    bool full = false;
    tGrille mainGrid;

    while(restart){
        #if DEBUG // smart way de le faire 
            tGrille test = {{4,3,5,2,6,9,7,8,1},{6,8,2,5,7,1,4,9,3},{1,9,7,8,3,4,5,6,2},{8,2,6,1,9,5,3,4,7},{3,7,4,6,8,2,9,1,5},{9,5,1,7,4,3,6,2,8},{5,1,9,3,2,6,8,7,4},{2,4,8,9,5,7,1,3,6},{7,6,3,4,1,8,2,5,0}}; // last one is a 9
            memcpy(mainGrid, &test, sizeof(tGrille));
        #else
            chargerGrille(mainGrid);
        #endif
        
        while (!full) {

            afficheGrille(mainGrid);

            printf("Entrez la position x: ");
            saisir(&posx);

            printf("Entrez la position y: ");
            saisir(&posy);

            printf("Entrez la valeur que vous souhaitez entrer à cette position: ");
            saisir(&val);

            if (possible(posx-1, posy-1, val, mainGrid)) mainGrid[posx-1][posy-1] = val;
            else printf("La valeur ne peut pas être ajoutée à la grille à cet emplacement.\n");
            full = grillePleine(mainGrid);
        }

        printf("Bravo, vous avez rempli la grille, voulez vous rejouer ?\n");

        while (1) {
        
        printf("Entrez votre réponse (oui/non) : ");
        scanf("%s", resp);

        if (strcmp(resp, "oui") == 0) {
            restart = true;
            full = false;
            break;
        } 
        else if (strcmp(resp, "non") == 0) {
            restart = false;
            break;
        }
        else {
            printf("Réponse invalide. Veuillez répondre par 'oui' ou 'non'.\n");
        }
    }
    
    }

    printf("Merci d'avoir joué.\n");

    return 0;
}


void chargerGrille(tGrille g) {
    char nomFichier[30];
    FILE *f;

    while (1) {
        printf("Nom du fichier ? ");
        scanf("%s", nomFichier);

        if (strstr(nomFichier, ".sud") == NULL) {
            printf("\nERREUR : Le fichier doit avoir l'extension \".sud\"\n");
            continue; // Re-prompt l'utilisateur pour un nouveau nom de fichier
        }

        f = fopen(nomFichier, "rb");

        if (f == NULL) {
            printf("\nERREUR sur le fichier %s\n", nomFichier);
            continue; // Re-prompt l'utilisateur pour un nouveau nom de fichier
        } 
        else {
            fread(g, sizeof(int), SIZE * SIZE, f);
            fclose(f);
            break;
        }
    }
}

/* template
    1  2  3   4  5  6   7  8  9
  +---------+---------+---------+
1 | 9  .  . | 6  .  . | 3  .  . |
2 | .  .  . | .  .  . | 4  6  9 |
3 | 6  .  . | 5  4  . | .  .  . |
  +---------+---------+---------+
4 | 3  7  8 | .  .  5 | .  .  2 |
5 | .  .  . | 7  6  2 | .  1  5 |
6 | .  6  . | 9  .  . | 7  .  4 |
  +---------+---------+---------+
7 | .  3  . | 1  5  7 | 9  .  6 |
8 | .  4  5 | 3  .  . | 1  2  . |
9 | 1  .  . | .  8  . | 5  .  . |
  +---------+---------+---------+
*/

void afficheGrille(tGrille grille) { // peut être plus compacte -> referais plus tard peut être ++ devrait color code les chiffres présents de base pour visibilité?
    //printf("start afficheG()\n");
    printf("    1  2  3   4  5  6   7  8  9\n");
    
    for (int i = 0; i < SIZE; i++) {
        if(!(i % 3)) printf("  +---------+---------+---------+\n");
        printf("%d |", i + 1);
        for (int j = 0; j < SIZE; j++) { // :)
            if (j % 3 == 0 && j != 0) printf("|");
            if (grille[i][j] == 0) printf(" . ");
            else printf(" %d ", grille[i][j]);
        }
        printf("|\n");
    }
    printf("  +---------+---------+---------+\n");
    //printf("endof afficheG()\n");
}

void saisir(int *pos){
    //printf("start saisir()\n");
    char nc[50];
    int prepos;

    while (1) {
        printf("Veuillez saisir un nombre entre 1 et %d: ", SIZE);
        scanf("%s", nc);
        if ((sscanf(nc, "%d", &prepos) == 1) && (prepos >= 1 && prepos <= SIZE)) {
            *pos = prepos;
            break;
        } else {
            printf("Erreur, l'entrée est invalide. Veuillez saisir un nombre entre 1 et %d.\n", SIZE);
        }
    }
    //printf("endof saisir()\n");
}

bool possible(int x, int y, int n, tGrille g) {
    bool ret = true;

    // Fast check
    if (g[x][y] != 0) ret = false;

    // Lignes colonnes
    for (int i = 0; i < SIZE; i++) if (g[x][i] == n || g[i][y] == n) ret = false; // :(

    // Bloc check
    int dlb = (x / 3) * 3; // Début ligne block
    int dlc = (y / 3) * 3; // Début colonne block

    for (int i = dlb; i < dlb + 3; i++) { // :)
        for (int j = dlc; j < dlc + 3; j++) {
            if (g[i][j] == n) ret = false;
        }
    }

    return ret;
}

bool grillePleine(tGrille g) {
    bool ret = true;
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (g[i][j] == 0) ret = false;
        }
    }
    return ret;
}